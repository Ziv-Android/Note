//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� MaintenTool.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAINTENTOOL_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_DLG_LOCAL_UPDATE            129
#define IDD_DLG_REMOTE_UPDATE           130
#define IDD_DIALOG1                     131
#define IDC_EDIT1                       1000
#define IDC_EDIT_IP                     1000
#define IDC_EDIT_PORT                   1000
#define IDC_UPDATE_FILE_EDIT            1000
#define IDC_EDIT_USERNAME               1001
#define IDC_PARAM_FILE_EDIT             1001
#define IDC_LIST_MULTI_IP               1002
#define IDC_BUTTON_SINGLE               1003
#define IDC_BUTTON2                     1004
#define IDC_EDIT_SERVER_USERNAME        1004
#define IDC_BUTTON3                     1005
#define IDC_EDIT_PWD                    1005
#define IDC_IPADDRESS1                  1006
#define IDC_BTN_                        1007
#define IDC_BTN_VIEW_LOG                1007
#define IDC_EDIT_SN                     1007
#define IDC_IPADDRESS2                  1007
#define IDC_LBL_STATUS                  1008
#define IDC_IPADDRESS3                  1008
#define IDC_LBL_STATUS2                 1009
#define IDC_LBL_MULTI_STATUS            1009
#define IDC_BTN_MULTI_UPDATE            1010
#define IDC_TAB_TYPE                    1011
#define IDC_EDIT_PWD2                   1011
#define IDC_EDIT_SERVER_PWD             1011
#define IDC_BTN_MULTI_IMPORT            1011
#define IDC_BTN_MULTI_UPDATE_DEVICE     1011
#define IDC_BTN_SEARCH_DEVICE           1012
#define IDC_EDIT_SERVER                 1013
#define IDC_EDIT_SERVER_PORT            1014
#define IDC_BTN_STOP_SEARCH             1014
#define IDC_LIST_REMOTE_MULTI_IP        1016
#define IDC_EDIT_PATH                   1017
#define IDC_BTN_BROWER                  1018
#define IDC_CHK_UPDATE                  1019
#define IDC_BTN_UPDATE_IP               1020
#define IDC_CMB_TYPE                    1021
#define IDC_BTN_BROW                    1022
#define IDC_BTN_PARAM                   1023
#define IDC_CMB_VERSION                 1024
#define IDC_LBL_TOTAL                   1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
