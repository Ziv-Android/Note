package com.example.scarx.idcardreader;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.zkteco.android.IDReader.WLTService;
import com.zkteco.android.IDReader.IDPhotoHelper;
import com.zkteco.android.biometric.core.device.ParameterHelper;
import com.zkteco.android.biometric.core.device.TransportType;
import com.zkteco.android.biometric.core.utils.HHDeviceControl;
import com.zkteco.android.biometric.core.utils.LogHelper;
import com.zkteco.android.biometric.core.utils.ToolUtils;
import com.zkteco.android.biometric.module.idcard.IDCardReader;
import com.zkteco.android.biometric.module.idcard.IDCardReaderFactory;
import com.zkteco.android.biometric.module.idcard.exception.IDCardReaderException;
import com.zkteco.android.biometric.module.idcard.meta.IDCardInfo;
import com.zkteco.android.biometric.module.idcard.meta.IDPRPCardInfo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import cn.pda.serialport.SerialPort;

public class MainActivity extends AppCompatActivity {
    private IDCardReader idCardReader = null;
    final static int idPort = 12;
    final static int baudrate = 115200;
    final static String idPower = "5V";
    private TextView textView = null;
    private ImageView imageView = null;
    private boolean bopen = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        textView = (TextView) findViewById(R.id.textView);
        imageView = (ImageView)findViewById(R.id.imageView);
        startIDCardReader();
    }

    public Context getContext()
    {
        return this.getApplicationContext();
    }

    private void startIDCardReader() {
        // Define output log level
        LogHelper.setLevel(Log.VERBOSE);
        // Start fingerprint sensor
        Map idrparams = new HashMap();
        idrparams.put(ParameterHelper.PARAM_SERIAL_BAUDRATE, baudrate);  //设置波特率
        //HHSERIALPORT 为ID500/ID510串口协议
        idCardReader = IDCardReaderFactory.createIDCardReader(this, TransportType.HHSERIALPORT, idrparams);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        HHDeviceControl.HHDevicePowerOff(idPower);
        IDCardReaderFactory.destroy(idCardReader);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume(){
        super.onResume();
        HHDeviceControl.HHDevicePowerOn(idPower);

    }

    public void OnBnOpen(View view)
    {
        try {
            if (bopen) return;
            HHDeviceControl.HHDevicePowerOn(idPower);
            idCardReader.open(idPort);
            bopen = true;
            textView.setText("连接设备成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("关闭设备成功");
            LogHelper.d("连接设备失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnClose(View view)
    {
        try {
            if (bopen)
            {
                idCardReader.close(idPort);
                //重要说明；ID500/ID510 关闭后需将串口切换到串口11.否则可能出现二代证无法使用
                HHDeviceControl.HHDeviceSwitchSerial(11);   //！！！重要！！！
                HHDeviceControl.HHDevicePowerOff(idPower);
                bopen = false;
            }
            textView.setText("关闭设备成功");
        }
        catch (IDCardReaderException e)
        {
            textView.setText("关闭设备失败");
            LogHelper.d("关闭设备失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }

    public void OnBnGetSamID(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            String samid = idCardReader.getSAMID(idPort);
            textView.setText("获取SAM编号成功："+ samid);
        }
        catch (IDCardReaderException e)
        {
            textView.setText("获取SAM编号失败");
            LogHelper.d("获取SAM模块失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }


    private void showMessage(String string)
    {
        new AlertDialog.Builder(this)
                .setTitle("提示")
                .setMessage(string)
                .setPositiveButton( "确定" ,
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i){
                            }
                        }).show();
    }

    public   String printHexString( byte[] b) {
        String a = "";
        for (int i = 0; i < 1024; i++) {
            String hex = Integer.toHexString(b[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            a = a+hex;
        }

        return a;
    }

    private boolean authenticate()
    {
        try {
            idCardReader.findCard(idPort);
            idCardReader.selectCard(idPort);
            return true;
        } catch (IDCardReaderException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void OnBnRead(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            if (!authenticate())
            {
                return;
            }
            int retCardType = idCardReader.readCardEx(0, 1);
            if (retCardType == 1 || retCardType == 2 || retCardType == 3) {
                if (retCardType == 1)   //居民身份证
                {
                    IDCardInfo idCardInfo = idCardReader.getLastIDCardInfo();
                    //姓名
                    String strName = idCardInfo.getName();
                    //民族
                    String strNation = idCardInfo.getNation();
                    //出生日期
                    String strBorn = idCardInfo.getBirth();
                    //住址
                    String strAddr = idCardInfo.getAddress();
                    //身份证号
                    String strID = idCardInfo.getId();
                    //有效期限
                    String strEffext = idCardInfo.getValidityTime();
                    //签发机关
                    String strIssueAt = idCardInfo.getDepart();

                    textView.setText(",姓名：" + strName +
                            "，民族：" + strNation + "，住址：" + strAddr + ",身份证号：" + strID);
                    if (idCardInfo.getPhotolength() > 0) {
                        byte[] buf = new byte[WLTService.imgLength];
                        if (1 == WLTService.wlt2Bmp(idCardInfo.getPhoto(), buf)) {
                            imageView.setImageBitmap(IDPhotoHelper.Bgr2Bitmap(buf));
                        }
                    }
                } else if (retCardType == 2)  //外国人永居证
                {
                    final IDPRPCardInfo idprpCardInfo = idCardReader.getLastPRPIDCardInfo();

                    //中文名
                    String strCnName = idprpCardInfo.getCnName();
                    //英文名
                    String strEnName = idprpCardInfo.getEnName();
                    //国家/国家地区代码
                    String strCountry = idprpCardInfo.getCountry() + "/" + idprpCardInfo.getCountryCode();//国家/国家地区代码
                    //出生日期
                    String strBorn = idprpCardInfo.getBirth();
                    //身份证号
                    String strID = idprpCardInfo.getId();
                    //有效期限
                    String strEffext = idprpCardInfo.getValidityTime();
                    //签发机关
                    String strIssueAt = "公安部";


                    textView.setText("中文名：" + strCnName + ",英文名：" +
                            strEnName + "，国家：" + strCountry + ",证件号：" + strID);
                    if (idprpCardInfo.getPhotolength() > 0) {
                        byte[] buf = new byte[WLTService.imgLength];
                        if (1 == WLTService.wlt2Bmp(idprpCardInfo.getPhoto(), buf)) {
                            imageView.setImageBitmap(IDPhotoHelper.Bgr2Bitmap(buf));
                        }
                    }
                } else    //港澳台居住证
                {
                    IDCardInfo idCardInfo = idCardReader.getLastIDCardInfo();
                    //姓名
                    String strName = idCardInfo.getName();
                    //民族,港澳台不支持该项
                    String strNation = "";
                    //出生日期
                    String strBorn = idCardInfo.getBirth();
                    //住址
                    String strAddr = idCardInfo.getAddress();
                    //身份证号
                    String strID = idCardInfo.getId();
                    //有效期限
                    String strEffext = idCardInfo.getValidityTime();
                    //签发机关
                    String strIssueAt = idCardInfo.getDepart();
                    //通行证号
                    String strPassNum = idCardInfo.getPassNum();
                    //签证次数
                    int visaTimes = idCardInfo.getVisaTimes();
                    textView.setText("姓名：" + strName +
                            "，住址：" + strAddr + ",身份证号：" + strID + "，通行证号码：" + strPassNum +
                            ",签证次数：" + visaTimes);
                    if (idCardInfo.getPhotolength() > 0) {
                        byte[] buf = new byte[WLTService.imgLength];
                        if (1 == WLTService.wlt2Bmp(idCardInfo.getPhoto(), buf)) {
                            imageView.setImageBitmap(IDPhotoHelper.Bgr2Bitmap(buf));
                        }
                    }
                }
            }
        } catch (IDCardReaderException e) {
            textView.setText("读卡失败");
            LogHelper.d("读卡失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }

    }
    public void OnBnGetVersionNum(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }

            byte[] dataVersion = new byte[1024];
            boolean ret=  idCardReader.Get_VersionNum(idPort, dataVersion);

            if (ret) {
                textView.setText("DataVersion:"+ new String(dataVersion));
            }
        } catch (IDCardReaderException e) {
            textView.setText("读版本号失败");
            LogHelper.d("读版本号失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }

    }
    public void OnBnMFWrite(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
                return;
            }
            byte mode = (byte)0x01;//写操作模式0或1
            byte blockCount = (byte)0x01;//要读多少块1-4
            byte startAddress = (byte)0x10;//16进制0x00-0x3F 即0到63块
            byte[]key = new byte[]{(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF};//6字节秘钥
            byte[]dataIn = new byte[]{0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10};//要写入的数据
            byte[] cardNum = new byte[20];//读出的卡序列号
            boolean ret=  idCardReader.MF_Write(idPort,mode,blockCount,startAddress,key,dataIn,cardNum);
            if (ret) {
                textView.setText(""+ ToolUtils.bytesToHexString(cardNum, 0, 4));
            }
        } catch (IDCardReaderException e) {
            textView.setText("写操作失败");
            LogHelper.d("写操作失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }
    public void OnBnMFRead(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
                return;
            }
            byte mode = (byte)0x01;//写操作模式0或1
            byte blockCount = (byte)0x01;//要读多少块1-4
            byte startAddress = (byte)0x10;//16进制0x00-0x3F 即0到63块
            byte[]key = new byte[]{(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF};//6字节秘钥

            byte[] dataCard = new byte[1024];//读出的卡数据
            byte[] cardNum = new byte[20];//读出卡序列号
            boolean ret=  idCardReader.MF_Read(idPort, mode, blockCount, startAddress, key,cardNum ,dataCard);

            if (ret) {
                textView.setText("cardNum:"+ ToolUtils.bytesToHexString(cardNum, 0, 4)+"     "+"dataCard:"+ ToolUtils.bytesToHexString(dataCard, 0, 16));

            }
        } catch (IDCardReaderException e) {
            textView.setText("写操作失败");
            LogHelper.d("写操作失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }
    }
    public void OnBnMF_GMF_GET_SNR(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
                return;
            }
            byte mode = (byte)0x26;//寻卡模式 0x52一次可以操作多张卡，0x26一次只对一张卡操作
            byte halt = (byte)0x00;//0x00不需要执行halt命令，0x01读写器执行halt命令
            byte[] cardNum = new byte[1024];//读出的数据
            boolean ret=  idCardReader.MF_GET_SNR(idPort,mode,halt, cardNum);

            if (ret) {
                textView.setText("cardNum:"+ ToolUtils.bytesToHexString(cardNum, 0, 4));
            }
        } catch (IDCardReaderException e) {
            textView.setText("寻卡操作失败");
            LogHelper.d("寻卡操作失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }

    }

    public void OnBnMF_GET_PhysicalCardNum(View view)
    {
        try {
            if (!bopen) {
                textView.setText("请先连接设备");
            }
            byte mode = (byte)0x52;//寻卡模式 0x52一次可以操作多张卡，0x26一次只对一张卡操作
            byte halt = (byte)0x01;//0x00不需要执行halt命令，0x01读写器执行halt命令
            byte[] physicalCardNum = new byte[1024];//读出的数据
            boolean ret=  idCardReader.MF_GET_NIDCardNum(idPort, mode, halt, physicalCardNum);

            if (ret) {
                textView.setText("cardNum:"+ ToolUtils.bytesToHexString(physicalCardNum, 0, 8));
            }
        } catch (IDCardReaderException e) {
            textView.setText("获取物理卡号失败");
            LogHelper.d("获取物理卡号失败, 错误码：" + e.getErrorCode() + "\n错误信息：" + e.getMessage() + "\n 内部错误码=" + e.getInternalErrorCode());
        }

    }


}
